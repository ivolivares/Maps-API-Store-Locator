# Google Maps API Store Locator for Pizza Locations :pizza:

To start this project use python simple HTTPs server.

First run the bash pem file generator:

    sh ./generate-pemfile.sh

Then, run the server:

    python start-server.py

The project runs at: [`https://localhost:4443`](https://localhost:4443).

> :rotating_light: Obviously, the browser says: "Your connection is not private", because the certificate authority is invalid (yourself)...  *Dont forget set an exception for this URL*.


---------
Made with :heart: by [@ivolivares](https://twitter.com/ivolivares)